warning: this directory is re/over/written from lwip2 builder upon lwip2 rebuild
